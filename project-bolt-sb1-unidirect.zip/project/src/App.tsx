import { GraduationCap, Globe2, Sparkles, Menu, X } from 'lucide-react';
import { useState } from 'react';

function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white">
      <nav className="border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <GraduationCap className="w-8 h-8 text-[#F15B53]" />
              <span className="text-2xl font-semibold text-[#0a192f]">UniDirect</span>
            </div>

            <div className="hidden md:flex items-center gap-8">
              <a href="#universities" className="text-[#0a192f] hover:text-[#F15B53] transition-colors">
                For Universities
              </a>
              <button className="bg-[#F15B53] text-white px-6 py-2.5 rounded-lg hover:bg-[#d94e47] transition-colors font-medium">
                Join Team
              </button>
            </div>

            <button
              className="md:hidden text-[#0a192f]"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {mobileMenuOpen && (
            <div className="md:hidden mt-4 pb-4 flex flex-col gap-4">
              <a href="#universities" className="text-[#0a192f] hover:text-[#F15B53] transition-colors">
                For Universities
              </a>
              <button className="bg-[#F15B53] text-white px-6 py-2.5 rounded-lg hover:bg-[#d94e47] transition-colors font-medium">
                Join Team
              </button>
            </div>
          )}
        </div>
      </nav>

      <section className="max-w-7xl mx-auto px-6 py-20 md:py-32">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-5xl md:text-6xl font-bold text-[#0a192f] leading-tight mb-6">
              Apply to Universities Worldwide with One Form
            </h1>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              Simplify your university application process. Connect with top institutions globally through our intelligent platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="bg-[#F15B53] text-white px-8 py-4 rounded-lg hover:bg-[#d94e47] transition-colors font-medium text-lg">
                Join Waitlist
              </button>
              <button className="border-2 border-[#0a192f] text-[#0a192f] px-8 py-4 rounded-lg hover:bg-[#0a192f] hover:text-white transition-colors font-medium text-lg">
                Hiring Now
              </button>
            </div>
          </div>

          <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-2xl p-8 h-96 flex items-center justify-center border border-gray-200">
            <div className="text-center text-gray-400">
              <GraduationCap className="w-24 h-24 mx-auto mb-4 opacity-50" />
              <p className="text-lg">Dashboard Preview</p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-gray-50 py-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-3 gap-12">
            <div className="bg-white p-8 rounded-2xl border border-gray-100 hover:shadow-lg transition-shadow">
              <div className="w-14 h-14 bg-[#F15B53] bg-opacity-10 rounded-xl flex items-center justify-center mb-6">
                <GraduationCap className="w-7 h-7 text-[#F15B53]" />
              </div>
              <h3 className="text-2xl font-semibold text-[#0a192f] mb-4">One Form Apply</h3>
              <p className="text-gray-600 leading-relaxed">
                Fill out one comprehensive application and submit to multiple universities instantly. Save time and effort.
              </p>
            </div>

            <div className="bg-white p-8 rounded-2xl border border-gray-100 hover:shadow-lg transition-shadow">
              <div className="w-14 h-14 bg-[#F15B53] bg-opacity-10 rounded-xl flex items-center justify-center mb-6">
                <Globe2 className="w-7 h-7 text-[#F15B53]" />
              </div>
              <h3 className="text-2xl font-semibold text-[#0a192f] mb-4">Global Reach</h3>
              <p className="text-gray-600 leading-relaxed">
                Access thousands of universities worldwide. Connect with institutions across continents with ease.
              </p>
            </div>

            <div className="bg-white p-8 rounded-2xl border border-gray-100 hover:shadow-lg transition-shadow">
              <div className="w-14 h-14 bg-[#F15B53] bg-opacity-10 rounded-xl flex items-center justify-center mb-6">
                <Sparkles className="w-7 h-7 text-[#F15B53]" />
              </div>
              <h3 className="text-2xl font-semibold text-[#0a192f] mb-4">AI Recommendations</h3>
              <p className="text-gray-600 leading-relaxed">
                Get personalized university matches based on your profile, preferences, and academic goals.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-[#0a192f] py-20">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            We Are Building the Future of Admissions
          </h2>
          <p className="text-xl text-gray-300 mb-8 leading-relaxed">
            Looking for Co-founders & Developers
          </p>
          <p className="text-lg text-gray-400 mb-10 leading-relaxed max-w-2xl mx-auto">
            Join our mission to revolutionize how students connect with universities. We're seeking talented individuals passionate about education and technology.
          </p>
          <button className="bg-[#F15B53] text-white px-10 py-4 rounded-lg hover:bg-[#d94e47] transition-colors font-medium text-lg">
            Join Our Team
          </button>
        </div>
      </section>

      <footer className="border-t border-gray-100 py-8">
        <div className="max-w-7xl mx-auto px-6 text-center text-gray-600">
          <p>© UniDirect 2025. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
